# WASSA EmoInt Competition Codalab Setup #

This is a copy of the Codalab bundle of the [EmoInt WASSA task](http://saifmohammad.com/WebPages/EmotionIntensity-SharedTask.html).

You can try uploading your own variation of this competition to the testing version of [Codalab](https://competitions-test.codalab.org) by doing the following:
  1. Download the competition [bundle](https://github.com/felipebravom/EmoInt/raw/master/codalab/competition.zip). 
  2. Upload it [here](https://competitions-test.codalab.org/competitions/create).

You can try submitting the following files to the development and testing phases:
  1. [submission-dev.zip](https://github.com/felipebravom/EmoInt/raw/master/codalab/submission-dev.zip)
  2. [submission-test.zip](https://github.com/felipebravom/EmoInt/raw/master/codalab/submission-test.zip)
